﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var monster = new SoulMaster("Ivan",12);
            System.Console.WriteLine(monster);
        }
    }
}