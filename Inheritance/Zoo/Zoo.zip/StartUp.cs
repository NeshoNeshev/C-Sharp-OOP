﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var snake = new Snake("pyton");
            System.Console.WriteLine(snake);
        }
    }
}