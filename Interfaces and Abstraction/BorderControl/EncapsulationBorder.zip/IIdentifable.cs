﻿
namespace BorderControl
{
    interface IIdentifable
    {
        
        public string Id { get;  }
    }
}
