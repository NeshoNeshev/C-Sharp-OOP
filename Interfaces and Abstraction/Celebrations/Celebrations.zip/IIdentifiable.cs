﻿
namespace BirthdayCelebrations
{
    interface IIdentifiable
    {
        public string Id { get; }
    }
}
