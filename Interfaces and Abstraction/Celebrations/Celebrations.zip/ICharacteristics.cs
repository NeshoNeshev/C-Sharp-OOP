﻿
namespace BirthdayCelebrations
{
    interface ICharacteristics
    {
        public string Name { get;}
        public string Birthdate { get;}
    }
}
