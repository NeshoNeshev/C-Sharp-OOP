﻿using System;
using System.Net.Security;

namespace BirthdayCelebrations
{
    class Program
    {
        static void Main(string[] args)
        {
            //Citizen <name> <age> <id> <birthdate>
            //Robot <model> <id>" 
            //Pet <name> <birthdate"
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
